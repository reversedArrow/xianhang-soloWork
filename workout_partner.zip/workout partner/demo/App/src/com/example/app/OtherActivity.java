package com.example.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class OtherActivity extends Activity {
	
	User user;
	private TextView info;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_other);
		
		if(getIntent() != null){
			user = (User) getIntent().getSerializableExtra("user");
		}
		
		info = (TextView) findViewById(R.id.info);
		
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("用户名："+user.username).append("\n")
			.append("账号："+user.account).append("\n")
			.append("密码："+user.password).append("\n")
			.append("手机："+user.phone).append("\n")
			.append("性别："+user.sex).append("\n")
			.append("爱好："+user.like).append("\n");
		
		info.setText(stringBuilder.toString());
		
	}
}
