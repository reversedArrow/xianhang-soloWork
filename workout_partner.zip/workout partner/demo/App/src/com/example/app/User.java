package com.example.app;

import java.io.Serializable;

public class User implements Serializable {
	
	public String username;
	public String account;
	public String password;
	public String phone;
	public String sex;
	public String like;

}
