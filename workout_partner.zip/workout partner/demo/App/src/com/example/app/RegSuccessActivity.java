package com.example.app;

import java.io.File;
import java.io.FileOutputStream;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class RegSuccessActivity extends Activity {

	TextView info;
	Button sp;
	Button txt;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_reg_success);
		info = (TextView) findViewById(R.id.info);
		sp = (Button) findViewById(R.id.btn_sp);
		txt = (Button) findViewById(R.id.btn_txt);
		
		if(getIntent() != null){
			String string = "用户名："+getIntent().getStringExtra("username")
					+ "\n密码："+getIntent().getStringExtra("password");
			info.setText(string);
		}
		
		sp.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				SharedPreferences sp = getSharedPreferences("user", MODE_PRIVATE);
				SharedPreferences.Editor editor = sp.edit();
				editor.putString("username", getIntent().getStringExtra("username"));
				editor.putString("password", getIntent().getStringExtra("password"));
				editor.commit();
				Toast.makeText(RegSuccessActivity.this, "保存成功", Toast.LENGTH_SHORT).show();
			}
		});
		txt.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				String filePath = null;
				boolean hasSDCard =Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED);
				if (hasSDCard) {
					filePath =Environment.getExternalStorageDirectory().toString() + File.separator +"dgut.txt";
				} else
					filePath =Environment.getDownloadCacheDirectory().toString() + File.separator +"dgut.txt";
					try {
						File file = new File(filePath);
						if (!file.exists()) {
							File dir = new File(file.getParent());
							dir.mkdirs();
							file.createNewFile();
						}
						FileOutputStream outStream = new FileOutputStream(file);
						outStream.write(info.getText().toString().getBytes());
						outStream.close();
						Toast.makeText(RegSuccessActivity.this, "保存成功", Toast.LENGTH_SHORT).show();
					} catch (Exception e) {
						Toast.makeText(RegSuccessActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
						e.printStackTrace();
					}
				}
		});
	}
}
