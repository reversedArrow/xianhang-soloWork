package com.example.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;

public class Ex1Activity431 extends Activity {
	
	private EditText username;
	private EditText account;
	private EditText password;
	private EditText phone;
	private RadioGroup sex;
	private CheckBox like_basketball;
	private CheckBox like_football;
	private CheckBox like_xiaqi;
	private CheckBox like_swimming;
	private Button reg;

	User user;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ex1_activity431);
        
        username = (EditText) findViewById(R.id.username);
        account = (EditText) findViewById(R.id.account);
        password = (EditText) findViewById(R.id.password);
        phone = (EditText) findViewById(R.id.phone);
        sex = (RadioGroup) findViewById(R.id.rg_sex);
        like_basketball = (CheckBox) findViewById(R.id.like_basketball);
        like_football = (CheckBox) findViewById(R.id.like_football);
        like_xiaqi = (CheckBox) findViewById(R.id.like_xiaqi);
        like_swimming = (CheckBox) findViewById(R.id.like_swimming);
        reg = (Button) findViewById(R.id.btn_reg);
        
        user = new User();
        
        sex.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(RadioGroup arg0, int arg1) {
				// TODO Auto-generated method stub
				if(arg1 == R.id.sex_man){
					user.sex = "男";
				}else{
					user.sex = "女";
				}
			}
		});
        reg.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				StringBuilder stringBuilder = new StringBuilder();
				user.username = username.getText().toString().trim();
				user.account = account.getText().toString().trim();
				user.password = password.getText().toString().trim();
				user.phone = phone.getText().toString().trim();
				if(like_basketball.isChecked()){
					stringBuilder.append("篮球；");
				}
				if(like_football.isChecked()){
					stringBuilder.append("足球；");
				}
				if(like_xiaqi.isChecked()){
					stringBuilder.append("下棋；");
				}
				if(like_swimming.isChecked()){
					stringBuilder.append("游泳；");
				}
				user.like = stringBuilder.toString();
				
//				Intent intent = new Intent(Ex1Activity431.this, OtherActivity.class);
//				intent.putExtra("user", user);
//				startActivity(intent);
				
				Intent intent2 = new Intent();
				intent2.setAction("com.example.app.OtherActivity");
				intent2.putExtra("user", user);
				startActivity(intent2);
			}
		});
    }
}
