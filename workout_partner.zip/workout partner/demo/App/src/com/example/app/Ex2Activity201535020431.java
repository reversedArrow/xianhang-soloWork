package com.example.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class Ex2Activity201535020431 extends Activity {
	
	EditText username;
	EditText password;
	Button regButton;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_ex2_activity201535020431);
		
		username = (EditText) findViewById(R.id.username);
		password = (EditText) findViewById(R.id.password);
		regButton = (Button) findViewById(R.id.btn_reg);
		
		regButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(Ex2Activity201535020431.this, RegSuccessActivity.class);
				intent.putExtra("username", username.getText().toString());
				intent.putExtra("password", password.getText().toString());
				startActivity(intent);
			}
		});
	}
}
