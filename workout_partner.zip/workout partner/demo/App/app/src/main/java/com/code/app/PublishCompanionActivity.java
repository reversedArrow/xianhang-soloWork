package com.code.app;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bigkoo.pickerview.builder.OptionsPickerBuilder;
import com.bigkoo.pickerview.builder.TimePickerBuilder;
import com.bigkoo.pickerview.listener.OnOptionsSelectListener;
import com.bigkoo.pickerview.listener.OnTimeSelectListener;
import com.bigkoo.pickerview.view.OptionsPickerView;
import com.bigkoo.pickerview.view.TimePickerView;
import com.code.app.bean.SportCompanion;
import com.code.app.utils.TimeUtil;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * 发起约伴界面
 */
public class PublishCompanionActivity extends AppCompatActivity implements View.OnClickListener{

    private LinearLayout back;
    private TextView title;

    private RelativeLayout rlTime;
    private TextView time;
    private EditText place;
    private RelativeLayout rlType;
    private TextView type;
    private EditText message;
    private Button publish;

    private List<String> types = Arrays.asList("篮球", "羽毛球", "乒乓球", "跑步", "爬山", "游泳");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_publish_companion);

        initToolbar();
        initView();
    }

    private void initView(){
        time = findViewById(R.id.tv_time);
        place = findViewById(R.id.et_place);
        type = findViewById(R.id.tv_type);
        message = findViewById(R.id.et_message);
        publish = findViewById(R.id.btn_publish);
        rlTime = findViewById(R.id.rl_time);
        rlType = findViewById(R.id.rl_type);

        publish.setOnClickListener(this);
        rlTime.setOnClickListener(this);
        rlType.setOnClickListener(this);

        time.setText(TimeUtil.getCurrTime(System.currentTimeMillis())); //默认显示当前时间
    }

    /**
     * 初始化标题栏
     */
    private void initToolbar() {
        back = findViewById(R.id.toolbar_back);
        title = findViewById(R.id.toolbar_title);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        title.setText("运动约伴");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_publish:
                publishCompanion();
                break;
            case R.id.rl_time: //选择时间
                TimePickerView pvTime = new TimePickerBuilder(this, new OnTimeSelectListener() {
                            @Override
                            public void onTimeSelect(Date date, View v) {
                                time.setText(TimeUtil.dateToString(date, TimeUtil.FORMAT_DATE_TIME));
                            }
                        })
                        .setType(new boolean[]{true, true, true, true, true, false})
                        .build();
                pvTime.setKeyBackCancelable(false);
                pvTime.show(v);
                break;
            case R.id.rl_type: //选择运动类型
                OptionsPickerView<String> pvOptions = new OptionsPickerBuilder(this, new OnOptionsSelectListener() {
                    @Override
                    public void onOptionsSelect(int options1, int option2, int options3 ,View v) {
                        type.setText(types.get(options1));
                    }
                }).build();
                pvOptions.setPicker(types);
                pvOptions.show();
                break;
        }
    }

    /**
     * 发起操作
     */
    private void publishCompanion(){
        String placeStr = place.getText().toString().trim();
        String msgStr = message.getText().toString().trim();
        if(TextUtils.isEmpty(placeStr) || TextUtils.isEmpty(msgStr)){
            Toast.makeText(this, "请仔细填写哦", Toast.LENGTH_SHORT).show();
            return;
        }


        SportCompanion sportCompanion = new SportCompanion();
        sportCompanion.id = String.valueOf(System.currentTimeMillis());
        sportCompanion.publisher = "user";
        sportCompanion.time = time.getText().toString();
        sportCompanion.place = placeStr;
        sportCompanion.type = type.getText().toString();
        sportCompanion.message = msgStr;
        // 传结果到上个界面
        getIntent().putExtra("sc", sportCompanion);
        setResult(RESULT_OK, getIntent());
        Toast.makeText(this, "发起成功！", Toast.LENGTH_SHORT).show();
        finish();
    }
}
