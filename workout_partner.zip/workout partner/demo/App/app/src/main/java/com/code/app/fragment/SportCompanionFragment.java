package com.code.app.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.code.app.CompanionDetailActivity;
import com.code.app.PublishCompanionActivity;
import com.code.app.R;
import com.code.app.adapter.SportCompanionAdapter;
import com.code.app.bean.CompanionApply;
import com.code.app.bean.SportCompanion;
import com.code.app.listener.OnRecyclerViewListener;
import com.code.app.utils.TimeUtil;

import java.util.ArrayList;
import java.util.List;

import static android.app.Activity.RESULT_OK;

/**
 * 约伴列表界面
 */
public class SportCompanionFragment extends Fragment {

    private EditText searchContent;
    private RecyclerView rvSportCompanion;
    private SportCompanionAdapter adapter;
    private List<SportCompanion> list = new ArrayList<>();
    private FloatingActionButton btnPublish;

    private final int PUBLISH_COMPANION_CODE = 101; //发起约伴请求码

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.f_sport_companion, container, false);
        initView(view);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        loadSportCompanion();
    }

    private void initView(View view){
        searchContent = view.findViewById(R.id.et_search_content);
        rvSportCompanion = view.findViewById(R.id.rv_companion);
        btnPublish = view.findViewById(R.id.fab_publish);

        btnPublish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { //进入发起约伴界面
                startActivityForResult(new Intent(getContext(),
                        PublishCompanionActivity.class), PUBLISH_COMPANION_CODE);
            }
        });

        searchContent.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s.length() > 0){ //有输入内容就开始搜索
                    search(s.toString());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        //初始化列表
        rvSportCompanion.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new SportCompanionAdapter();
        rvSportCompanion.setAdapter(adapter);

        adapter.setOnRecyclerViewListener(new OnRecyclerViewListener<SportCompanion>() {
            @Override
            public void onItemClick(int position, SportCompanion data) {
                // 进入详情页
                Intent intent = new Intent(getContext(), CompanionDetailActivity.class);
                intent.putExtra("sc", data);
                startActivity(intent);
            }
        });
    }

    /**
     * 搜索操作
     *
     * @param str
     */
    private void search(String str){

    }

    /**
     * 加载约伴请求
     */
    private void loadSportCompanion(){
        for(int i=0;i<5;i++){
            SportCompanion sportCompanion = new SportCompanion();
            sportCompanion.id = String.valueOf(System.currentTimeMillis());
            sportCompanion.publisher = "user";
            sportCompanion.time = TimeUtil.getCurrTime(System.currentTimeMillis());
            sportCompanion.place = "西北体育场";
            sportCompanion.type = "跑步";
            sportCompanion.message = "跑步的定义是指陆生动物使用足部移动。它在运动上的定义是一种步伐，双脚不会同一时间踫到地面。它亦可以是一种有氧的运动或厌氧的运动。";
            list.add(sportCompanion);
        }

        adapter.setDatas(list);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == RESULT_OK){
            if(requestCode == PUBLISH_COMPANION_CODE){
                //接受传过来的结果
                SportCompanion sportCompanion = (SportCompanion) data.getSerializableExtra("sc");
                //刷新界面
                adapter.addData(sportCompanion);
            }
        }
    }
}
