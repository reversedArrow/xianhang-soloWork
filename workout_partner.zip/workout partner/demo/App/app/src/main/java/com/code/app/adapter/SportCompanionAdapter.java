package com.code.app.adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.code.app.R;
import com.code.app.bean.SportCompanion;
import com.code.app.listener.OnRecyclerViewListener;

import java.util.ArrayList;
import java.util.List;


/**
 * 约伴列表适配器
 */
public class SportCompanionAdapter extends RecyclerView.Adapter<SportCompanionAdapter.MyHolder>{

    private List<SportCompanion> dataList = new ArrayList<>();

    public void setDatas(List<SportCompanion> list) {
        dataList.clear();
        if (null != list) {
            dataList.addAll(list);
            notifyDataSetChanged();
        }
    }

    public void addData(SportCompanion data){
        dataList.add(data);
        notifyDataSetChanged();
    }

    /**
     * 清空数据
     */
    public void clear(){
        dataList.clear();
        notifyDataSetChanged();
    }

    @Override
    public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MyHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_companion,
                parent, false));
    }

    @Override
    public void onBindViewHolder(MyHolder holder, int position) {
        holder.bindData(position, dataList.get(position));
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        ImageView avatar;
        TextView name;
        TextView time;
        TextView type;
        TextView place;
        TextView message;
        Button join;

        public MyHolder(View itemView) {
            super(itemView);

            avatar = itemView.findViewById(R.id.avatar);
            name = itemView.findViewById(R.id.name);
            time = itemView.findViewById(R.id.time);
            type = itemView.findViewById(R.id.type);
            place = itemView.findViewById(R.id.place);
            message = itemView.findViewById(R.id.message);
            join = itemView.findViewById(R.id.btn_join);
        }

        /**
         * 绑定一条数据
         *
         * @param bean
         */
        public void bindData(final int position, final SportCompanion bean) {
            name.setText(bean.publisher);
            time.setText(bean.time);
            type.setText(bean.type);
            place.setText(bean.place);
            message.setText(bean.message);

            join.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //加入请求
                }
            });
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(onRecyclerViewListener != null){
                        onRecyclerViewListener.onItemClick(position, bean);
                    }
                }
            });
        }
    }

    private OnRecyclerViewListener<SportCompanion> onRecyclerViewListener;

    public void setOnRecyclerViewListener(OnRecyclerViewListener<SportCompanion> onRecyclerViewListener) {
        this.onRecyclerViewListener = onRecyclerViewListener;
    }
}
