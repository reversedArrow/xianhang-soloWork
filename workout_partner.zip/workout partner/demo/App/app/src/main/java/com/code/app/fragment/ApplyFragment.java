package com.code.app.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.code.app.R;
import com.code.app.adapter.CompanionApplyAdapter;
import com.code.app.bean.CompanionApply;
import com.code.app.utils.TimeUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * 约伴申请界面
 */
public class ApplyFragment extends Fragment {

    private EditText searchContent;
    private RecyclerView rvSportCompanion;
    private CompanionApplyAdapter adapter;
    private List<CompanionApply> list = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.f_companion_apply, container, false);
        initView(view);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        loadApply();
    }

    private void initView(View view) {
        searchContent = view.findViewById(R.id.et_search_content);
        rvSportCompanion = view.findViewById(R.id.rv_companion_apply);

        searchContent.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) { //有输入内容就开始搜索
                    search(s.toString());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        //初始化列表
        rvSportCompanion.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new CompanionApplyAdapter();
        rvSportCompanion.setAdapter(adapter);

    }

    /**
     * 搜索操作
     *
     * @param str
     */
    private void search(String str){

    }

    /**
     * 获取对应的申请
     */
    private void loadApply(){
        for(int i=0;i<5;i++){
            CompanionApply apply = new CompanionApply();
            apply.id = String.valueOf(System.currentTimeMillis());
            apply.applyer = "李海";
            apply.time = TimeUtil.getCurrTime(System.currentTimeMillis());
            apply.status = "0";
            list.add(apply);
        }

        adapter.setDatas(list);
    }
}
