package com.code.app.listener;

/**
 * 列表点击事件
 */
public interface OnRecyclerViewListener<T> {

    void onItemClick(int position, T data);
}
