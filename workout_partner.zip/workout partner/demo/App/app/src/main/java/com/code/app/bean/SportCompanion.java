package com.code.app.bean;

import java.io.Serializable;

/**
 * 运动约伴实体类
 */
public class SportCompanion implements Serializable {

    public String id;
    public String publisher;
    public String time;
    public String place;
    public String type;
    public String message;
}
