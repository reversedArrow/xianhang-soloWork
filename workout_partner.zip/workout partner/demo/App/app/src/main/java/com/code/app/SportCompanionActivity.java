package com.code.app;

import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.code.app.fragment.ApplyFragment;
import com.code.app.fragment.SportCompanionFragment;

/**
 * 运动约伴界面
 */
public class SportCompanionActivity extends AppCompatActivity {

    private LinearLayout back;
    private TextView title;

    private TabLayout tabLayout;
    private ViewPager viewPager;

    private final String[] titles = {"约伴请求", "管理申请"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sport_companion);

        initToolbar();
        initView();
    }

    private void initView(){
        tabLayout = findViewById(R.id.tab_companion);
        viewPager = findViewById(R.id.vp_companion);

        // 设置左右滑动界面
        viewPager.setAdapter(new FragmentPagerAdapter(getSupportFragmentManager()) {
            @Override
            public int getCount() {
                return 2;
            }

            @Override
            public Fragment getItem(int position) {
                if(position == 0){
                    return new SportCompanionFragment();
                }else{
                    return new ApplyFragment();
                }
            }

            @Override
            public CharSequence getPageTitle(int position) {
                return titles[position];
            }
        });
        tabLayout.setupWithViewPager(viewPager);
    }

    /**
     * 初始化标题栏
     */
    private void initToolbar() {
        back = findViewById(R.id.toolbar_back);
        title = findViewById(R.id.toolbar_title);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        title.setText("运动约伴");
    }
}
