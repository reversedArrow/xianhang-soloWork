package com.code.app.bean;

/**
 * 约伴申请实体类
 */
public class CompanionApply {

    public String id;
    public String applyer;
    public String time;
    public String status; // 0 等待处理  1 已同意  2 已拒绝
}
