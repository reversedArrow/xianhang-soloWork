package com.code.app.adapter;

import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.code.app.R;
import com.code.app.bean.CompanionApply;
import com.code.app.bean.SportCompanion;
import com.code.app.listener.OnRecyclerViewListener;

import java.util.ArrayList;
import java.util.List;


/**
 * 约伴申请适配器
 */
public class CompanionApplyAdapter extends RecyclerView.Adapter<CompanionApplyAdapter.MyHolder>{

    private List<CompanionApply> dataList = new ArrayList<>();

    public void setDatas(List<CompanionApply> list) {
        dataList.clear();
        if (null != list) {
            dataList.addAll(list);
            notifyDataSetChanged();
        }
    }

    public void addData(CompanionApply data){
        dataList.add(data);
        notifyDataSetChanged();
    }

    /**
     * 清空数据
     */
    public void clear(){
        dataList.clear();
        notifyDataSetChanged();
    }

    @Override
    public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MyHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_apply,
                parent, false));
    }

    @Override
    public void onBindViewHolder(MyHolder holder, int position) {
        holder.bindData(position, dataList.get(position));
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        ImageView avatar;
        TextView name;
        TextView time;
        ImageView btn_agree;
        ImageView btn_refuse;
        TextView status_tip;

        public MyHolder(View itemView) {
            super(itemView);

            avatar = itemView.findViewById(R.id.avatar);
            name = itemView.findViewById(R.id.name);
            time = itemView.findViewById(R.id.time);
            btn_agree = itemView.findViewById(R.id.btn_agree);
            btn_refuse = itemView.findViewById(R.id.btn_refuse);
            status_tip = itemView.findViewById(R.id.status_tip);
        }

        /**
         * 绑定一条数据
         *
         * @param bean
         */
        public void bindData(final int position, final CompanionApply bean) {
            // 名字，申请时间
            name.setText(bean.applyer);
            time.setText(bean.time);

            if(bean.status.equals("0")){ //未处理
                btn_agree.setVisibility(View.VISIBLE);
                btn_refuse.setVisibility(View.VISIBLE);
                status_tip.setVisibility(View.GONE);
            }
            if(bean.status.equals("1")){ //已同意
                btn_agree.setVisibility(View.GONE);
                btn_refuse.setVisibility(View.GONE);
                status_tip.setVisibility(View.VISIBLE);
                status_tip.setText("已同意");
            }
            if(bean.status.equals("2")){ //已拒绝
                btn_agree.setVisibility(View.GONE);
                btn_refuse.setVisibility(View.GONE);
                status_tip.setVisibility(View.VISIBLE);
                status_tip.setText("已拒绝");
                status_tip.setTextColor(Color.RED);
            }

            btn_agree.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { //同意
                    bean.status = "1";
                    btn_agree.setVisibility(View.GONE);
                    btn_refuse.setVisibility(View.GONE);
                    status_tip.setVisibility(View.VISIBLE);
                    status_tip.setText("已同意");
                }
            });
            btn_refuse.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { //拒绝
                    bean.status = "2";
                    btn_agree.setVisibility(View.GONE);
                    btn_refuse.setVisibility(View.GONE);
                    status_tip.setVisibility(View.VISIBLE);
                    status_tip.setText("已拒绝");
                    status_tip.setTextColor(Color.RED);
                }
            });

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(onRecyclerViewListener != null){
                        onRecyclerViewListener.onItemClick(position, bean);
                    }
                }
            });
        }
    }

    private OnRecyclerViewListener<CompanionApply> onRecyclerViewListener;

    public void setOnRecyclerViewListener(OnRecyclerViewListener<CompanionApply> onRecyclerViewListener) {
        this.onRecyclerViewListener = onRecyclerViewListener;
    }
}
